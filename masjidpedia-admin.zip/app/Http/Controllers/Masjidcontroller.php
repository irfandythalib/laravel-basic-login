<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use App\Models\Masjid;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Exception;

class Masjidcontroller extends Controller
{
    public function index()
    {
        try {
            if (!Auth::check()) {
                return redirect('/login')->with('message', 'Anda tidak punya akses ke halaman ini');
            }
            $data = Masjid::get();
            // return $data;
            return view('masjid', ['data' => $data]);
        } catch (Exception $exception) {
            return back()->withError($exception->getMessage())->withInput();
        }
    }

    public function create()
    {
        try {
            if (!Auth::check()) {
                return redirect('/login')->with('message', 'Anda tidak punya akses ke halaman ini');
            }
            return view('masjid_create', []);
        } catch (Exception $exception) {
            return back()->withError($exception->getMessage())->withInput();
        }
    }
    public function store(Request $request)
    {
        try {
            if (!Auth::check()) {
                return redirect('/login')->with('message', 'Anda tidak punya akses ke halaman ini');
            }
            $request->validate([
                'nama' => 'required|max:100',
                'alamat' => 'required|max:500',
                'username' => 'required|max:200',
                'urlhost' => 'required|max:200',
                'password' => 'required|min:7',
            ]);
            $masjid = new Masjid;
            $masjid->masjid_nama = $request->nama;
            $masjid->username = $request->username;
            $masjid->password =  Hash::make($request->password);
            $masjid->masjid_alamat = $request->alamat;
            $masjid->url = $request->urlhost;
            $masjid->save();
// return $request;

            return redirect('masjid')->with('success', 'Masjid berhasil ditambahkan');
        } catch (Exception $exception) {
            return $exception->getMessage();
            return back()->withError($exception->getMessage())->withInput();
        }
    }

    // // public function show($id)
    // // {
    // // }
    // public function edit($id)
    // {
    //     try {
    //         if ((new Libcontroller)->cekLogin() == False) {
    //             return redirect('/login')->with('message', 'Anda tidak punya akses ke halaman ini');
    //         }

    //         $profil = Profil::where('app_id', $this->app_id())->first();

    //         $blog = new Blog;
    //         $blog = $blog->where('id', $id);
    //         $blog = $blog->first();
    //         // $kanal = Kanal::all();
    //         return view('admin/blog_edit', ['profil' => $profil, 'data' => $blog]);
    //     } catch (Exception $exception) {
    //         return back()->withError($exception->getMessage())->withInput();
    //     }
    // }

    // public function update(Request $request)
    // {
    //     try {
    //         if ((new Libcontroller)->cekLogin() == False) {
    //             return redirect('/login')->with('message', 'Anda tidak punya akses ke halaman ini');
    //         }
    //         // Handle Image
    //         if (!isset($request->image) or $request->image == null) {
    //             $imageName = $request->currentimage;
    //         } else {
    //             #Hapus gambar lama jika gambar baru terisi
    //             unlink("assets/images/blog/" . $request->currentimage);

    //             #Upload gambar baru
    //             $request->validate([
    //                 'image' => 'required|image|mimes:png,jpg,jpeg|max:2048'
    //             ]);
    //             $imageName = time() . '.' . $request->image->extension();
    //             $request->image->move(public_path('assets/images/blog'), $imageName);
    //         }

    //         if ($request->content != "") {
    //             // Handle: Upload image summernote body
    //             // To implement: Remove image from server when removed in summernote -->
    //             // https://stackoverflow.com/questions/28078159/summernote-delete-image-from-server
    //             $content = $request->content;
    //             $dom = new \DomDocument();
    //             @$dom->loadHtml($content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    //             $imageFile = $dom->getElementsByTagName('img');
    //             foreach ($imageFile as $item => $image) {
    //                 $data = $image->getAttribute('src');
    //                 if (str_contains($data, 'data:image')) {
    //                     list($type, $data) = explode(';', $data);
    //                     list(, $data)      = explode(',', $data);
    //                     $imgeData = base64_decode($data);
    //                     $image_name = "/assets/images/blog/content/" . time() . $item . '.png';
    //                     $path = public_path() . $image_name;
    //                     file_put_contents($path, $imgeData);
    //                     $image->removeAttribute('src');
    //                     $image->setAttribute('src', $image_name);
    //                 }
    //             }
    //             $content = $dom->saveHTML();
    //         } else {
    //             $content = "";
    //         }

    //         $dateupdated = date('Y-m-d');
    //         DB::update(
    //             "update tabel_blog set judul_blog=?, isi_blog=?, date_updated=?, gambar_blog=?, kategori_blog=? where id=?",
    //             [$request->judul, $content, $dateupdated, $imageName, $request->kategori, $request->id]
    //         );
    //         return redirect('admin/blog');
    //     } catch (Exception $exception) {
    //         return back()->withError($exception->getMessage())->withInput();
    //     }
    // }

    // public function destroy($id)
    // {
    //     try {
    //         if ((new Libcontroller)->cekLogin() == False) {
    //             return redirect('/login')->with('message', 'Anda tidak punya akses ke halaman ini');
    //         }
    //         Blog::find($id)->delete();
    //         return redirect('admin/blog')->with('message', 'Blog berhasil dihapus!');
    //     } catch (Exception $exception) {
    //         return back()->withError($exception->getMessage())->withInput();
    //     }
    // }
}
